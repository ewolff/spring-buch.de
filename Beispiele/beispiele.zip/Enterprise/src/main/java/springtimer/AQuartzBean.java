package springtimer;

import java.util.Date;

public class AQuartzBean {

	private static boolean called = false;

	public static boolean isCalled() {
		return called;
	}

	public void doIt() {
		called = true;
		AQuartzBean.class.notifyAll();
	}

}
