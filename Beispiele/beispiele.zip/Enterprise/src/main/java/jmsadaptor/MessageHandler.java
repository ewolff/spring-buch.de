package jmsadaptor;


public class MessageHandler {

	private boolean called=false;
	
    public boolean isCalled() {
		return called;
	}

	public void handleJMSMessage(String message) {
		called=true;
		MessageHandler.class.notifyAll();
    }

    
}
