package springjmspojo;

import org.springframework.jms.core.JmsTemplate;
import org.springframework.jms.listener.AbstractJmsListeningContainer;
import org.springframework.test.AbstractDependencyInjectionSpringContextTests;

public class MessageDrivenPojoTest extends
		AbstractDependencyInjectionSpringContextTests {

	private MessageDrivenPojoMessageListener messageListenerPojo;

	private JmsTemplate jmsTemplatePojo;
	
	private AbstractJmsListeningContainer jmsContainerPojo;

	public void setJmsContainerPojo(AbstractJmsListeningContainer jmsContainerPojo) {
		this.jmsContainerPojo = jmsContainerPojo;
	}

	public void setJmsTemplatePojo(JmsTemplate jmsTemplate) {
		this.jmsTemplatePojo = jmsTemplate;
	}

	public void setMessageListenerPojo(
			MessageDrivenPojoMessageListener messageListenerPojo) {
		this.messageListenerPojo = messageListenerPojo;
	}

	public MessageDrivenPojoTest() {
		super();
		setAutowireMode(AUTOWIRE_BY_NAME);
	}

	@Override
	protected String[] getConfigLocations() {
		return new String[] { "jms.xml" };
	}

	public void testAdaptor() throws InterruptedException {
		assertFalse(messageListenerPojo.isCalled());
		jmsTemplatePojo.convertAndSend("Eine Message");
		synchronized (MessageDrivenPojoMessageListener.class) {
			MessageDrivenPojoMessageListener.class.wait(5000);
		}
		assertTrue(messageListenerPojo.isCalled());
		jmsContainerPojo.shutdown();
	}

}
