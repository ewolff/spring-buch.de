package jmsadaptor;

import org.springframework.jms.core.JmsTemplate;
import org.springframework.jms.listener.AbstractJmsListeningContainer;
import org.springframework.test.AbstractDependencyInjectionSpringContextTests;

import springjmspojo.MessageDrivenPojoMessageListener;

public class MessageHandlerTest extends
		AbstractDependencyInjectionSpringContextTests {

	private MessageHandler messageHandler;

	private JmsTemplate jmsTemplateMessageHandler;
	
	private AbstractJmsListeningContainer jmsContainerMessageHandler;

	public void setJmsContainerMessageHandler(
			AbstractJmsListeningContainer jmsContainerMessageHandler) {
		this.jmsContainerMessageHandler = jmsContainerMessageHandler;
	}

	public void setJmsTemplateMessageHandler(JmsTemplate jmsTemplate) {
		this.jmsTemplateMessageHandler = jmsTemplate;
	}

	public MessageHandlerTest() {
		super();
		setAutowireMode(AUTOWIRE_BY_NAME);
	}

	public void setMessageHandler(MessageHandler messageHandler) {
		this.messageHandler = messageHandler;
	}

	@Override
	protected String[] getConfigLocations() {
		return new String[] { "jms.xml" };
	}

	public void testAdaptor() throws InterruptedException {
		assertFalse(messageHandler.isCalled());
		jmsTemplateMessageHandler.convertAndSend("Eine Message");
		synchronized (MessageHandler.class) {
			MessageHandler.class.wait(5000);
		}
		assertTrue(messageHandler.isCalled());
		jmsContainerMessageHandler.shutdown();
	}
	
}
