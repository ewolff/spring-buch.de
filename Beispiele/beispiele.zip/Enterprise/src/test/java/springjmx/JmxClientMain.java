package springjmx;

import java.lang.management.MemoryMXBean;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.test.AbstractDependencyInjectionSpringContextTests;

public class JmxClientMain  extends AbstractDependencyInjectionSpringContextTests {

	private MemoryMXBean memoryMXBean;
	
    @Override
	protected String[] getConfigLocations() {
    	return new String[]{"jmx-client.xml"};
    }
	public void setMemoryMXBean(MemoryMXBean memoryMXBean) {
		this.memoryMXBean = memoryMXBean;
	}

	public void testMemoryMXBean() {
		assertTrue(memoryMXBean.getObjectPendingFinalizationCount()>=0); 
    }


}
