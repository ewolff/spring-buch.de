package springtimer;

import junit.framework.TestCase;

import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class QuartzTest extends TestCase {

    public static void testQuartz() throws InterruptedException {
    	assertFalse(AQuartzBean.isCalled());
    	ConfigurableApplicationContext applicationContext = new ClassPathXmlApplicationContext("quartz.xml");
    	synchronized (AQuartzBean.class) {
    		AQuartzBean.class.wait(5000);
		}
    	assertTrue(AQuartzBean.isCalled());
        applicationContext.close();
    }

}
