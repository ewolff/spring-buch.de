package jmsexporter;

import org.springframework.jms.listener.AbstractMessageListenerContainer;
import org.springframework.test.AbstractDependencyInjectionSpringContextTests;

public class KundeDAOTest extends AbstractDependencyInjectionSpringContextTests {

	public KundeDAOTest() {
		super();
		setAutowireMode(AUTOWIRE_BY_NAME);
	}

	protected String[] getConfigLocations() {
		return new String[] { "jms.xml" };
	}

	private IKundeDAO kundeDAO;

	private AbstractMessageListenerContainer jmsPojoContainer;

	public void setJmsPojoContainer(
			AbstractMessageListenerContainer jmsPojoContainer) {
		this.jmsPojoContainer = jmsPojoContainer;
	}

	public void setKundeDAO(IKundeDAO kundeDAO) {
		this.kundeDAO = kundeDAO;
	}

	public void testConversion() {
		Kunde kunde = kundeDAO.getById(42);
		assertEquals("wolff", kunde.getName());
		jmsPojoContainer.shutdown();
	}

}
