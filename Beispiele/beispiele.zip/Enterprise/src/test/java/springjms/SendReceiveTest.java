package springjms;

import javax.jms.JMSException;
import javax.jms.Message;
import javax.jms.Session;

import org.springframework.jms.core.JmsTemplate;
import org.springframework.jms.core.MessageCreator;
import org.springframework.test.AbstractDependencyInjectionSpringContextTests;

public class SendReceiveTest extends
		AbstractDependencyInjectionSpringContextTests {

	private JmsTemplate jmsTemplateSend;

	private JmsTemplate jmsTemplateReceive;

	private static int received = 0;

	public SendReceiveTest() {
		super();
		setAutowireMode(AUTOWIRE_BY_NAME);
	}

	public void setJmsTemplateSend(JmsTemplate jmsTemplate) {
		this.jmsTemplateSend = jmsTemplate;
	}

	public void setJmsTemplateReceive(JmsTemplate jmsTemplateReceive) {
		this.jmsTemplateReceive = jmsTemplateReceive;
	}

	@Override
	protected String[] getConfigLocations() {
		return new String[] { "jms.xml" };
	}

	public void testSendReceive() throws InterruptedException {
		Thread receiverThread=new Thread(new Runnable() {
			public void run() {
				while (received<2) {
					String result = (String) jmsTemplateReceive
							.receiveAndConvert();
					if (result.equals("JMS Message")) {
						received++;
					}
				}
			}
		});
		receiverThread.start();
		assertEquals(0, received);
		jmsTemplateSend.send(new MessageCreator() {

			public Message createMessage(Session session) throws JMSException {
				return session.createTextMessage("JMS Message");
			}

		});
		jmsTemplateSend.convertAndSend("JMS Message");
		receiverThread.join();
		assertEquals(2, received);
	}

}
