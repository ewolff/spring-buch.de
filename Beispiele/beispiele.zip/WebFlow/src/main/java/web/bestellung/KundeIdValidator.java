package web.bestellung;

import org.springframework.validation.Errors;
import org.springframework.validation.Validator;

import businessobjects.Einkaufswagen;
import dao.IKundeDAO;

public class KundeIdValidator implements Validator {
    private IKundeDAO kundeDAO;

    public boolean supports(Class clazz) {
        return (clazz.equals(Einkaufswagen.class));
    }

    public void validate(Object obj, Errors errors) {
        Einkaufswagen einkaufswagen = (Einkaufswagen) obj;
        if (kundeDAO.getByID(einkaufswagen.getId_Kunde()) == null) {
            errors.reject("kunde.nichtgefunden", "Kunde nicht gefunden!");
        }
    }

    public IKundeDAO getKundeDAO() {
        return kundeDAO;
    }

    public void setKundeDAO(IKundeDAO kundeDAO) {
        this.kundeDAO = kundeDAO;
    }

}