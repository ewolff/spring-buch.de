package web.bestellung;

import org.springframework.webflow.action.FormAction;
import org.springframework.webflow.execution.Event;
import org.springframework.webflow.execution.RequestContext;

import businessobjects.Einkaufswagen;
import businessprocess.BestellungException;
import businessprocess.IBestellungBusinessProcess;

public class BestellungAufgebenAction extends FormAction {

    private IBestellungBusinessProcess bestellung;

    public IBestellungBusinessProcess getBestellung() {
        return bestellung;
    }

    public void setBestellung(IBestellungBusinessProcess bestellung) {
        this.bestellung = bestellung;
    }

    public Event bestellungAufgeben(RequestContext context) {
        Einkaufswagen einkaufswagen = (Einkaufswagen) context.getFlowScope()
                .get("einkaufswagen");
        try {
            bestellung.bestellen(einkaufswagen);
        } catch (BestellungException e) {
        	e.printStackTrace();
            return result("fehler");
        }
        return result("erfolg");
    }

}
