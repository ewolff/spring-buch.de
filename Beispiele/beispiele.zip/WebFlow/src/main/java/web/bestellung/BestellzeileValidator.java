package web.bestellung;

import org.springframework.validation.Errors;
import org.springframework.validation.Validator;

import businessobjects.EinkaufswagenInhalt;

import dao.IWareDAO;

public class BestellzeileValidator implements Validator {

	private IWareDAO wareDAO;

	public void setWareDAO(IWareDAO wareDAO) {
		this.wareDAO = wareDAO;
	}

	public boolean supports(Class clazz) {
		return clazz.equals(EinkaufswagenInhalt.class);
	}

	public void validate(Object obj, Errors errors) {
		EinkaufswagenInhalt einkaufswagenInhalt = (EinkaufswagenInhalt) obj;
		if (wareDAO.getByID(einkaufswagenInhalt.getId_Ware()) == null) {
			errors.reject("ware.nichtgefunden", "Ware nicht gefunden!");
		}
	}

}
