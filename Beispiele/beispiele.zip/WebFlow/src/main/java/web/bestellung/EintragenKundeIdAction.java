package web.bestellung;


import org.springframework.webflow.action.FormAction;
import org.springframework.webflow.execution.Event;
import org.springframework.webflow.execution.RequestContext;

import businessobjects.Einkaufswagen;
import dao.IKundeDAO;

public class EintragenKundeIdAction extends FormAction {

    private IKundeDAO kundeDAO;
    
    public EintragenKundeIdAction() {
        super();
        setFormObjectName("einkaufswagen");
        setFormObjectClass(Einkaufswagen.class);
    }

    public IKundeDAO getKundeDAO() {
        return kundeDAO;
    }

    public void setKundeDAO(IKundeDAO kundeDAO) {
        this.kundeDAO = kundeDAO;
    }

    public Event eintragenKundenId(RequestContext context) {
        return result("erfolg");
    }
    
}
