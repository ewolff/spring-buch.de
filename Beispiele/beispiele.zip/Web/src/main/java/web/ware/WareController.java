package web.ware;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.multiaction.MultiActionController;

import web.IdCommand;
import web.StringCommand;

import businessobjects.Ware;

import dao.IWareDAO;

public class WareController extends MultiActionController {

    private IWareDAO wareDAO;

    public IWareDAO getWareDAO() {
        return wareDAO;
    }

    public void setWareDAO(IWareDAO wareDAO) {
        this.wareDAO = wareDAO;
    }

    private String successView = "";

    public String getSuccessView() {
        return successView;
    }

    public void setSuccessView(String successView) {
        this.successView = successView;
    }

    private String wareListeView = "";

    public String getWareListeView() {
        return wareListeView;
    }

    public void setWareListeView(String wareView) {
        this.wareListeView = wareView;
    }

    public ModelAndView deleteByBezeichnung(HttpServletRequest req,
            HttpServletResponse res, String name) {
        wareDAO.deleteByBezeichnung(name); //.getName());
        return new ModelAndView(getSuccessView());
    }

    public ModelAndView deleteByID(HttpServletRequest req,
            HttpServletResponse res, IdCommand id) {
        wareDAO.deleteByID(id.getId());
        return new ModelAndView(getSuccessView());
    }

    public ModelAndView getByBezeichnung(HttpServletRequest req,
            HttpServletResponse res, StringCommand name) {
        Map model = new HashMap();
        List wareListe = wareDAO.getByBezeichnung(name.getName());
        model.put("wareListe", wareListe);
        return new ModelAndView(wareListeView, model);
    }

    public ModelAndView getByID(HttpServletRequest req,
            HttpServletResponse res, IdCommand id) {
        Map model = new HashMap();
        Ware ware = wareDAO.getByID(id.getId());
        List wareListe = new ArrayList();
        wareListe.add(ware);
        model.put("wareListe", wareListe);
        return new ModelAndView(wareListeView, model);

    }

    public ModelAndView create(HttpServletRequest req, HttpServletResponse res,
            Ware ware) {
        wareDAO.save(ware);
        return new ModelAndView(getSuccessView());
    }

    public ModelAndView getAll(HttpServletRequest req, HttpServletResponse res) {
        return new ModelAndView(wareListeView, "wareListe", wareDAO.getAll());
    }

}
