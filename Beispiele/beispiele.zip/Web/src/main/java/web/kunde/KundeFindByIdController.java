package web.kunde;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.web.servlet.ModelAndView;

import web.IdCommand;

import businessobjects.Kunde;

public class KundeFindByIdController extends KundeSimpleFormController {
    
    private String view = "kundenListe";
    
    public void setView(String view) {
        this.view = view;
    }
   
    public KundeFindByIdController() {
        setCommandClass(IdCommand.class);
        setCommandName("id");
    }

    protected ModelAndView onSubmit(Object command) throws Exception {
        IdCommand idCommand = (IdCommand) command;
        Map model = new HashMap();
        List kundenListe = new ArrayList();
        kundenListe.add(kundeDAO.getByID(idCommand.getId()));
        model.put("kundenListe",kundenListe);
        return new ModelAndView(view, model);
    }

}
