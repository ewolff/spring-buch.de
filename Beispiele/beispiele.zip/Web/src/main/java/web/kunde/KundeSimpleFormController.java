package web.kunde;

import org.springframework.web.servlet.mvc.SimpleFormController;

import dao.IKundeDAO;

public abstract class KundeSimpleFormController extends SimpleFormController {

    protected IKundeDAO kundeDAO;

    public IKundeDAO getKundeDAO() {
        return kundeDAO;
    }

    public void setKundeDAO(IKundeDAO kundeDAO) {
        this.kundeDAO = kundeDAO;
    }

}
