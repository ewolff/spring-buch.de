package web.kunde;

import org.springframework.web.servlet.ModelAndView;

import web.StringCommand;

public class KundeDeleteByNameController extends KundeSimpleFormController {

    public KundeDeleteByNameController() {
        setCommandClass(StringCommand.class);
        setCommandName("name");
    }

    protected ModelAndView onSubmit(Object command) throws Exception {
        StringCommand nameCommand = (StringCommand) command;
        kundeDAO.deleteByName(nameCommand.getName());
        return new ModelAndView(getSuccessView());
    }

}