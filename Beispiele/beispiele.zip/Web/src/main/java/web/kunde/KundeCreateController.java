package web.kunde;

import org.springframework.web.servlet.ModelAndView;

import businessobjects.Kunde;

public class KundeCreateController extends KundeSimpleFormController {

    public KundeCreateController() {
        setCommandClass(Kunde.class);
        setCommandName("kunde");
    }

    protected ModelAndView onSubmit(Object command) throws Exception {
        Kunde kunde = (Kunde) command;
        kunde = kundeDAO.save(kunde);
        return new ModelAndView(getSuccessView(), "kundeID", Integer
                .toString(kunde.getId()));
    }
}