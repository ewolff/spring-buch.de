package web.kunde;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.web.servlet.ModelAndView;

import web.StringCommand;

public class KundeFindByNameController extends KundeSimpleFormController {

    private String view = "kundenListe";

    public void setView(String view) {
        this.view = view;
    }

    public KundeFindByNameController() {
        setCommandClass(StringCommand.class);
        setCommandName("name");
    }

    protected ModelAndView onSubmit(Object command) throws Exception {
        StringCommand nameCommand = (StringCommand) command;
        Map model = new HashMap();
        List kundenListe = kundeDAO.getByName(nameCommand.getName());
        model.put("kundenListe", kundenListe);
        return new ModelAndView(view, model);
    }

}
