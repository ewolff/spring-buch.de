package web.kunde;

import org.springframework.web.servlet.ModelAndView;

import web.IdCommand;

public class KundeDeleteByIdController extends KundeSimpleFormController {

    public KundeDeleteByIdController() {
        setCommandClass(IdCommand.class);
        setCommandName("id");
    }

    protected ModelAndView onSubmit(Object command) throws Exception {
        IdCommand idCommand = (IdCommand) command;
        kundeDAO.deleteByID(idCommand.getId());
        return new ModelAndView(getSuccessView());
    }

}