package remotetest;

public class BurlapTest extends RemoteBase {

	protected String[] getConfigLocations() {
		return new String[] {"rmi-client.xml", "rmi-server.xml"};
	}

}
