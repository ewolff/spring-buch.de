package remotetest;

public class HessianTest extends RemoteBase {

	protected String[] getConfigLocations() {
		return new String[] {"hessian-client.xml"};
	}

}
