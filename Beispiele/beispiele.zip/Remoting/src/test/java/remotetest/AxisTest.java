package remotetest;

public class AxisTest extends RemoteBase {

	protected String[] getConfigLocations() {
		return new String[] {"axis-client.xml"};
	}

}
