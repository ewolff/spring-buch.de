package remotetest;

public class XFireTest extends RemoteBase {

	protected String[] getConfigLocations() {
		return new String[] { "xfire-client.xml" };
	}

}
