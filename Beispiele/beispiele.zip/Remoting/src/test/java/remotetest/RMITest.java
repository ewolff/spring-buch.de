package remotetest;

import org.apache.xbean.spring.context.ClassPathXmlApplicationContext;
import org.springframework.context.ApplicationContext;

public class RMITest extends RemoteBase {

	private static ApplicationContext server = new ClassPathXmlApplicationContext(		"rmi-server.xml");

	protected String[] getConfigLocations() {
		return new String[] { "rmi-client.xml"  };
	}

}
