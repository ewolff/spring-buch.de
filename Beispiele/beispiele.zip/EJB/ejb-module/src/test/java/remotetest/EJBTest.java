package remotetest;

public class EJBTest extends RemoteBase {

}
