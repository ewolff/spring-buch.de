package ejb;

import java.util.List;

import javax.ejb.CreateException;

import org.springframework.ejb.support.AbstractStatelessSessionBean;

import businessobjects.Bestellung;

import dao.IBestellungDAO;

/**
 * @ejb.bean description="Bestellung DAO Stateless Session Bean"
 *           display-name="Bestellung DAO Stateless Session Bean"
 *           jndi-name="BestellungDAOEJB"
 *           name="BestellungDAOEJB"
 *           type="Stateless"
 *           view-type="remote"
 *           transaction-type="Bean"
 * 
 * @ejb.env-entry name="ejb/BeanFactoryPath" value="ejb-server.xml"
 */

public class BestellungDAOEJB extends AbstractStatelessSessionBean implements IBestellungDAO {

    private IBestellungDAO bestellungDAO;

    protected void onEjbCreate() throws CreateException {
        bestellungDAO = (IBestellungDAO) getBeanFactory().getBean(
                "bestellungDAO");
    }

    /**
     * @ejb.interface-method view-type = "remote"
     */
    public List getByIDKunde(int id_kunde) {
        return bestellungDAO.getByIDKunde(id_kunde);
    }

    /**
     * @ejb.interface-method view-type = "remote"
     */
    public Bestellung save(Bestellung bestellung) {
        return bestellungDAO.save(bestellung);
    }

    /**
     * @ejb.interface-method view-type = "remote"
     */
    public void deleteByIDKunde(int id_kunde) {
        bestellungDAO.deleteByIDKunde(id_kunde);
    }

}