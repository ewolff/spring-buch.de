package ejb;

import javax.ejb.CreateException;

import org.springframework.ejb.support.AbstractStatelessSessionBean;

import businessobjects.Einkaufswagen;
import businessprocess.BestellungException;
import businessprocess.IBestellungBusinessProcess;

/**
 * @ejb.bean description="Bestellung Business Process Stateless Session Bean"
 *           display-name="Bestellung Business Process Stateless Session Bean"
 *           jndi-name="BestellungBusinessProcessEJB"
 *           name="BestellungBusinessProcessEJB"
 *           type="Stateless"
 *           view-type="remote" transaction-type="Bean"
 * 
 * @ejb.env-entry name = "ejb/BeanFactoryPath" value="ejb-server.xml"
 */
public class BestellungBusinessProcessEJB extends AbstractStatelessSessionBean
        implements IBestellungBusinessProcess {
    IBestellungBusinessProcess bestellungBusinessProcess;

    protected void onEjbCreate() throws CreateException {
        bestellungBusinessProcess = (IBestellungBusinessProcess) getBeanFactory()
                .getBean("bestellung");
    }

    /**
     * @ejb.interface-method view-type = "remote"
     */
    public void bestellen(Einkaufswagen einkaufswagen)
            throws BestellungException {
        bestellungBusinessProcess.bestellen(einkaufswagen);
    }

}