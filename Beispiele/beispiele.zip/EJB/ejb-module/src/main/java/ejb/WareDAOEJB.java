package ejb;

import java.util.List;

import javax.ejb.CreateException;

import org.springframework.ejb.support.AbstractStatelessSessionBean;

import businessobjects.Ware;
import dao.IWareDAO;

/**
 * @ejb.bean description="Ware DAO Stateless Session Bean"
 *          display-name="Ware DAO Stateless Session Bean"
 *          jndi-name="WareDAOEJB"
 *          name="WareDAOEJB"
 *          type="Stateless"
 *          view-type="remote"
 *          transaction-type="Bean"
 * 
 * @ejb.env-entry name = "ejb/BeanFactoryPath" value="ejb-server.xml"
 */

public class WareDAOEJB extends AbstractStatelessSessionBean {

    private IWareDAO wareDAO;

    protected void onEjbCreate() throws CreateException {
        wareDAO = (IWareDAO) getBeanFactory().getBean("wareDAO");
    }

    /**
     * @ejb.interface-method view-type = "remote"
     */

    public void deleteByBezeichnung(String bezeichnung) {
        wareDAO.deleteByBezeichnung(bezeichnung);
    }

    /**
     * @ejb.interface-method view-type = "remote"
     */

    public void deleteByID(int id) {
        wareDAO.deleteByID(id);
    }

    /**
     * @ejb.interface-method view-type = "remote"
     */

    public List getByBezeichnung(String bezeichnung) {
        return wareDAO.getByBezeichnung(bezeichnung);
    }

    /**
     * @ejb.interface-method view-type = "remote"
     */

    public Ware getByID(int id) {
        return wareDAO.getByID(id);
    }

    /**
     * @ejb.interface-method view-type = "remote"
     */

    public Ware save(Ware ware) {
        return wareDAO.save(ware);
    }

    /**
     * @ejb.interface-method view-type = "remote"
     */

    public void update(Ware ware) {
        wareDAO.update(ware);
    }

}
