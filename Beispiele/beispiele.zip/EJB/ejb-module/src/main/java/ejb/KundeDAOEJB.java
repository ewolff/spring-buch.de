package ejb;

import java.util.List;

import javax.ejb.CreateException;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.ejb.support.AbstractStatelessSessionBean;

import businessobjects.Kunde;
import dao.IKundeDAO;

/**
 * @ejb.bean description="Kunde DAO Stateless Session Bean" display-name="Kunde
 *           DAO Stateless Session Bean" jndi-name="KundeDAOEJB"
 *           name="KundeDAOEJB" type="Stateless" view-type="remote"
 *           transaction-type="Bean"
 * 
 * @ejb.env-entry name="ejb/BeanFactoryPath" value="ejb-server.xml"
 */

public class KundeDAOEJB extends AbstractStatelessSessionBean implements
        IKundeDAO {

    private Log log = LogFactory.getLog(KundeDAOEJB.class);
    
    private IKundeDAO kundeDAO;

    protected void onEjbCreate() throws CreateException {
        log.error("in onEjbCreate()");
        System.out.println("in onEjbCreate()");
        try {
            kundeDAO = (IKundeDAO) getBeanFactory().getBean("kundeDAO");
        } catch (Exception ex) {
            log.error("Exception",ex);
            ex.printStackTrace();
        }
    }

    /**
     * @ejb.interface-method view-type = "remote"
     */
    public void deleteByID(int id) {
        kundeDAO.deleteByID(id);
    }

    /**
     * @ejb.interface-method view-type = "remote"
     */
    public void deleteByName(String name) {
        kundeDAO.deleteByName(name);
    }

    /**
     * @ejb.interface-method view-type = "remote"
     */
    public Kunde getByID(int id) {
        return kundeDAO.getByID(id);
    }

    /**
     * @ejb.interface-method view-type = "remote"
     */
    public List getByName(String name) {
        return kundeDAO.getByName(name);
    }

    /**
     * @ejb.interface-method view-type = "remote"
     */

    public Kunde save(Kunde kunde) {
        return kundeDAO.save(kunde);
    }

    /**
     * @ejb.interface-method view-type = "remote"
     */
    public void update(Kunde kunde) {
        kundeDAO.update(kunde);
    }

    public List getAll() {
        return kundeDAO.getAll();
    }
}