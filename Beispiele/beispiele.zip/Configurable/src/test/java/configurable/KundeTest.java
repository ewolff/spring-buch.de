package configurable;

import junit.framework.TestCase;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class KundeTest extends TestCase {

	public static void testDao() {
		ApplicationContext applicationContext = new ClassPathXmlApplicationContext(
				"beans.xml");
		assertEquals(0, KundeDAO.getCalls());
		Kunde kunde = new Kunde();
		kunde.save();
		assertEquals(1, KundeDAO.getCalls());
		kunde = new Kunde2();
		kunde.save();
		assertEquals(2, KundeDAO.getCalls());
	}

}
