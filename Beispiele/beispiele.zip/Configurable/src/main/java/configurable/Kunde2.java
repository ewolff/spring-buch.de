package configurable;


import org.springframework.beans.factory.annotation.Autowire;
import org.springframework.beans.factory.annotation.Configurable;

@Configurable(autowire = Autowire.BY_TYPE, dependencyCheck = true)
public class Kunde2 extends Kunde {

}
