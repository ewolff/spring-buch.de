package configurable;


import org.springframework.beans.factory.annotation.Configurable;

@Configurable("kunde")
public class Kunde {

    private KundeDAO kundeDAO;

    public void setKundeDAO(KundeDAO kundeDAO) {
        this.kundeDAO = kundeDAO;
    }

    public void save() {
        kundeDAO.save(this);
    }

}
