package configurable;


public class KundeDAO {

	private static int calls;
	
    public void save(Kunde kunde) {
    	calls++;
    }

	public static int getCalls() {
		return calls;
	}
    
}
