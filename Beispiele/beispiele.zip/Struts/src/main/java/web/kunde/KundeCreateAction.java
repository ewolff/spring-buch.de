package web.kunde;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;
import org.springframework.web.struts.ActionSupport;

import businessobjects.Kunde;
import dao.IKundeDAO;

public class KundeCreateAction extends ActionSupport {

    private IKundeDAO kundeDAO;

    public void setKundeDAO(IKundeDAO kundeDAO) {
        this.kundeDAO = kundeDAO;
    }

    public ActionForward execute(ActionMapping mapping, ActionForm form,
            HttpServletRequest req, HttpServletResponse res) throws Exception {
        Kunde kunde = ((KundeCreateActionForm) form).getKunde();
        kundeDAO.save(kunde);
        return mapping.findForward("kundeCreated");
    }
}
