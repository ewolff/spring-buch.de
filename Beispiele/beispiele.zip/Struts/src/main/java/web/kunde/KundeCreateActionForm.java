package web.kunde;

import javax.servlet.http.HttpServletRequest;

import org.apache.struts.action.ActionErrors;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionMapping;
import org.apache.struts.action.ActionMessage;
import org.apache.struts.action.ActionMessages;

import businessobjects.Kunde;

public class KundeCreateActionForm extends ActionForm {

    private Kunde kunde = new Kunde();

    public Kunde getKunde() {
        return kunde;
    }

    public void setKunde(Kunde kunde) {
        this.kunde = kunde;
    }

    public void reset(ActionMapping arg0, HttpServletRequest arg1) {
        kunde = new Kunde();
    }

    public ActionErrors validate(ActionMapping map, HttpServletRequest req) {
        ActionErrors errors = new ActionErrors();

        if ((kunde.getVorname() == null) || (kunde.getVorname().equals(""))) {
            errors.add(ActionMessages.GLOBAL_MESSAGE, new ActionMessage(
                    "required", "Vorname"));
        }
        if ((kunde.getName() == null) || (kunde.getName().equals(""))) {
            errors.add(ActionMessages.GLOBAL_MESSAGE, new ActionMessage(
                    "required", "Name"));
        }
        if (kunde.getKontostand() < 0.0) {
            errors.add(ActionMessages.GLOBAL_MESSAGE, new ActionMessage(
                    "negativ", "Kontostand"));
        }

        return errors;
    }

}
