package client;

import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URL;

import javax.xml.soap.MessageFactory;
import javax.xml.soap.Name;
import javax.xml.soap.SOAPBodyElement;
import javax.xml.soap.SOAPConnection;
import javax.xml.soap.SOAPConnectionFactory;
import javax.xml.soap.SOAPElement;
import javax.xml.soap.SOAPEnvelope;
import javax.xml.soap.SOAPException;
import javax.xml.soap.SOAPFault;
import javax.xml.soap.SOAPMessage;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

public class Bestellen {

	public static final String NAMESPACE_URI = "http://www.spring-buch.de/ws";

	public static final String PREFIX = "tns";

	private SOAPConnectionFactory connectionFactory;

	private MessageFactory messageFactory;

	private URL url;

	private TransformerFactory transfomerFactory;

	public Bestellen(String url) throws SOAPException, MalformedURLException {
		connectionFactory = SOAPConnectionFactory.newInstance();
		messageFactory = MessageFactory.newInstance();
		transfomerFactory = TransformerFactory.newInstance();
		this.url = new URL(url);
	}

	private SOAPMessage createBestellenRequest(int anzahl, int id_ware) throws SOAPException {
		SOAPMessage message = messageFactory.createMessage();
		SOAPEnvelope envelope = message.getSOAPPart().getEnvelope();
		Name bestellenRequestName = envelope.createName("bestellenRequest",
				PREFIX, NAMESPACE_URI);
		SOAPBodyElement bestellenRequestElement = message.getSOAPBody()
				.addBodyElement(bestellenRequestName);

		Name einkaufswagenName = envelope.createName("einkaufswagen", PREFIX,
				NAMESPACE_URI);
		SOAPElement einkaufswagenElement = bestellenRequestElement
				.addChildElement(einkaufswagenName);

		Name kundeIdName = envelope.createName("kunde-id", PREFIX,
				NAMESPACE_URI);
		SOAPElement kundeIdElement = einkaufswagenElement
				.addChildElement(kundeIdName);
		kundeIdElement.setValue("95");

		Name einkaufswagenInhaltName = envelope.createName(
				"einkaufswagen-inhalt", PREFIX, NAMESPACE_URI);
		SOAPElement einkaufswagenInhaltElement = einkaufswagenElement
				.addChildElement(einkaufswagenInhaltName);

		Name anzahlName = envelope.createName("anzahl", PREFIX, NAMESPACE_URI);
		SOAPElement anzahlElement = einkaufswagenInhaltElement
				.addChildElement(anzahlName);
		anzahlElement.setValue(Integer.toString(anzahl));
		Name idWareName = envelope.createName("id-ware", PREFIX, NAMESPACE_URI);
		SOAPElement idWareElement = einkaufswagenInhaltElement
				.addChildElement(idWareName);
		idWareElement.setValue(Integer.toString(id_ware));

		return message;
	}

	public void bestellen(int anzahl, int id_ware) throws SOAPException, IOException,
			TransformerException {
		SOAPMessage request = createBestellenRequest(anzahl,id_ware);
		outputMessage(request);
		SOAPConnection connection = connectionFactory.createConnection();
		SOAPMessage response = connection.call(request, url);
		if (!response.getSOAPBody().hasFault()) {
			outputMessage(response);
		} else {
			outputMessage(response);
			SOAPFault fault = response.getSOAPBody().getFault();
			System.err.println("Received SOAP Fault");
			System.err.println("SOAP Fault Code :" + fault.getFaultCode());
			System.err.println("SOAP Fault String :" + fault.getFaultString());
		}
	}

	private void outputMessage(SOAPMessage message) throws SOAPException,
			TransformerException {
		SOAPEnvelope envelope = message.getSOAPPart().getEnvelope();
		Transformer transformer = transfomerFactory.newTransformer();
		transformer.setOutputProperty(OutputKeys.OMIT_XML_DECLARATION, "yes");
		transformer.setOutputProperty(OutputKeys.INDENT, "yes");
		DOMSource source = new DOMSource(envelope);
		transformer.transform(source, new StreamResult(System.out));
	}

	public static void main(String[] args) throws Exception {
		String url = "http://localhost:8080/springbuchws/services";
		if (args.length > 0) {
			url = args[0];
		}
		Bestellen bestellen = new Bestellen(url);
		bestellen.bestellen(1,82);
		bestellen.bestellen(1,21);
	}
}
