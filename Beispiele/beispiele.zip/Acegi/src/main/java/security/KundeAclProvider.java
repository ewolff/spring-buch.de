package security;

import org.acegisecurity.Authentication;
import org.acegisecurity.acl.AclEntry;
import org.acegisecurity.acl.AclProvider;
import org.acegisecurity.acl.basic.SimpleAclEntry;
import org.acegisecurity.userdetails.UserDetails;

import businessobjects.Kunde;

public class KundeAclProvider implements AclProvider {

    public AclEntry[] getAcls(Object domainInstance) {
        return new AclEntry[] { new SimpleAclEntry() };
    }

    public AclEntry[] getAcls(Object domainInstance,
            Authentication authentication) {
        Kunde kunde = (Kunde) domainInstance;
        String username = ((UserDetails) authentication.getPrincipal())
                .getUsername();
        if (username.equalsIgnoreCase(kunde.getName())) {
            SimpleAclEntry result = new SimpleAclEntry();
            result.setMask(SimpleAclEntry.READ_WRITE_CREATE_DELETE);
            return new AclEntry[] { result };
        } else {
            return getAcls(domainInstance);
        }
    }

    public boolean supports(Object domainInstance) {
        return domainInstance.getClass().equals(Kunde.class);
    }

}
