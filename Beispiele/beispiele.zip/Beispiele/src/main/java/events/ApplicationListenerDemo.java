package events;

import org.springframework.context.ApplicationEvent;
import org.springframework.context.ApplicationListener;

public class ApplicationListenerDemo implements ApplicationListener {

	private boolean called;
	
    public boolean isCalled() {
		return called;
	}

	public void onApplicationEvent(ApplicationEvent event) {
        System.out.println(event);
        called=true;
    }

    
    
}
