package komplexetypen;

public enum EineEnumeration {
    
    WERT, ANDERER_WERT

}
