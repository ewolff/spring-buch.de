package introductions;

public interface CallCounter {
    int getCounter();
}