package events;

import org.springframework.test.AbstractDependencyInjectionSpringContextTests;

public class ApplicationListenerTest extends AbstractDependencyInjectionSpringContextTests  {

	private ApplicationListenerDemo applicationListenerDemo;
	
    @Override
	protected String[] getConfigLocations() {
    	return new String[] {"events.xml"};    	
	}

    public void testEvent() {
    	applicationContext.publishEvent(new MyEvent(applicationContext));
    	assertTrue(applicationListenerDemo.isCalled());
    }
    
	public void setApplicationListenerDemo(
			ApplicationListenerDemo applicationListenerDemo) {
		this.applicationListenerDemo = applicationListenerDemo;
	}


}
