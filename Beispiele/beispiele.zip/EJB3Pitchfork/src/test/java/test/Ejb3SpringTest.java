package test;

import junit.framework.TestCase;

import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.access.BeanFactoryLocator;
import org.springframework.beans.factory.access.BeanFactoryReference;
import org.springframework.context.access.DefaultLocatorFactory;

import ejb3springintegration.SpringBean;
import ejb3springintegration.StatelessSessionBean;

public class Ejb3SpringTest extends TestCase {

    public void testIntegration() {
        BeanFactoryLocator beanFactoryLocator = DefaultLocatorFactory
                .getInstance();
        BeanFactoryReference beanFactoryReference = beanFactoryLocator
                .useBeanFactory("ejb3factory");
        BeanFactory beanFactory = beanFactoryReference.getFactory();
        SpringBean slsb = (SpringBean) beanFactory.getBean("springBean");
        assertFalse(slsb.isDoItCalled());
        StatelessSessionBean statelessSessionBean = new StatelessSessionBean();
        statelessSessionBean.acquireBeanFactory();
        statelessSessionBean.doIt();
        statelessSessionBean.releaseBeanFactory();
        assertTrue(slsb.isDoItCalled());
        beanFactoryReference.release();
    }

}
