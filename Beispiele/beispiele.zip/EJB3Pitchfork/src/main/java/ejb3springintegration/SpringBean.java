package ejb3springintegration;

public class SpringBean implements SLSBInterface {

    private boolean doItCalled = false;

    public void doIt() {
        doItCalled = true;
    }

    public boolean isDoItCalled() {
        return doItCalled;
    }

}
