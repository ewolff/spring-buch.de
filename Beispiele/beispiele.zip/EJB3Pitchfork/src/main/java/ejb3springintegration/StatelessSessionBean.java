package ejb3springintegration;

import javax.annotation.PostConstruct;
import javax.annotation.PreDestroy;
import javax.ejb.Stateless;

import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.access.BeanFactoryLocator;
import org.springframework.beans.factory.access.BeanFactoryReference;
import org.springframework.context.access.DefaultLocatorFactory;

@Stateless
public class StatelessSessionBean implements SLSBInterface {

    private SLSBInterface slsb;

    private BeanFactoryReference beanFactoryReference;

    public void doIt() {
        slsb.doIt();
    }

    @PostConstruct
    public void acquireBeanFactory() {
        BeanFactoryLocator beanFactoryLocator = DefaultLocatorFactory
                .getInstance();
        beanFactoryReference = beanFactoryLocator.useBeanFactory("ejb3factory");
        BeanFactory beanFactory = beanFactoryReference.getFactory();
        slsb = (SLSBInterface) beanFactory.getBean("springBean");
    }

    @PreDestroy
    public void releaseBeanFactory() {
        if (beanFactoryReference != null) {
            beanFactoryReference.release();
        }
    }

}
