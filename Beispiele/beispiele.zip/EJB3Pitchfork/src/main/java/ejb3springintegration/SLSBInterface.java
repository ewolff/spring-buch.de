package ejb3springintegration;

import javax.ejb.Local;

@Local
public interface SLSBInterface {
    
    void doIt();

}