package springconfiguration;

import javax.sql.DataSource;

import org.apache.commons.dbcp.BasicDataSource;
import org.springframework.beans.factory.annotation.Bean;
import org.springframework.beans.factory.annotation.Configuration;
import org.springframework.context.java.AnnotationApplicationContext;
import org.springframework.jdbc.datasource.DataSourceTransactionManager;
import org.springframework.transaction.PlatformTransactionManager;

import springjdbcdao.BestellungDAO;
import springjdbcdao.KundeDAO;
import springjdbcdao.WareDAO;
import businessprocess.BestellungBusinessProcess;
import businessprocess.IBestellungBusinessProcess;
import dao.IBestellungDAO;
import dao.IKundeDAO;
import dao.IWareDAO;

@Configuration
public class SpringConfiguration {

    @Bean
    public DataSource dataSource() {
        BasicDataSource dataSource = new BasicDataSource();
        dataSource.setDriverClassName("org.hsqldb.jdbcDriver");
        dataSource.setUrl("jdbc:hsqldb:file:springbuchhsqldb");
        dataSource.setUsername("sa");
        dataSource.setPassword("");
        return dataSource;
    }
    
    @Bean
    public PlatformTransactionManager transactionManager() {
        return new DataSourceTransactionManager(dataSource());
    }

    @Bean
    public IKundeDAO kundeDAO() {
        return new KundeDAO(dataSource());
    }

    @Bean
    public IWareDAO wareDAO() {
        return new WareDAO(dataSource());
    }

    @Bean
    public IBestellungDAO bestellungDAO() {
        return new BestellungDAO(dataSource(),kundeDAO(),wareDAO());
    }
    
    @Bean
    public IBestellungBusinessProcess bestellung() {
        return new BestellungBusinessProcess(bestellungDAO(),kundeDAO(),wareDAO());
    }

    public static void main(String[] args) {
        new AnnotationApplicationContext(SpringConfiguration.class.getName());
    }
    
}
