#!/bin/sh

#mkdir ../target/beandoc
BEANDOCHOME=/Users/wolff/spring-beandoc-0.7.0
CLASSPATH=.:$BEANDOCHOME/target/dist/spring-beandoc.jar:$BEANDOCHOME/target/dist/spring-core.jar:$BEANDOCHOME/target/dist/spring-beans.jar:$BEANDOCHOME/target/dist/jdom.jar:$BEANDOCHOME/target/dist/commons-logging.jar
java -cp $CLASSPATH org.springframework.beandoc.client.BeanDocClient --properties ./beandoc.properties
