package base;

import junit.framework.TestCase;

import org.easymock.MockControl;
import org.easymock.internal.AlwaysMatcher;

import businessobjects.Bestellung;
import businessobjects.Einkaufswagen;
import businessobjects.Kunde;
import businessobjects.Ware;
import businessprocess.BestellungBusinessProcess;
import businessprocess.BestellungException;
import dao.IBestellungDAO;
import dao.IKundeDAO;
import dao.IWareDAO;

public class BestellungOhneSpringTest extends TestCase {

    private MockControl bestellungDAOControl;

    private IBestellungDAO bestellungDAOMock;

    private MockControl kundeDAOControl;

    private IKundeDAO kundeDAOMock;

    private MockControl wareDAOControl;

    private IWareDAO wareDAOMock;

    private BestellungBusinessProcess bestellung;

    private Kunde kunde;

    private Ware ware;

    protected void setUp() throws Exception {
        super.setUp();
        kundeDAOControl = MockControl.createControl(IKundeDAO.class);
        kundeDAOMock = (IKundeDAO) kundeDAOControl.getMock();
        kunde = new Kunde("Eberhard", "Wolff", 42.0);
        kunde.setId(42);
        bestellungDAOControl = MockControl.createControl(IBestellungDAO.class);
        bestellungDAOMock = (IBestellungDAO) bestellungDAOControl.getMock();
        wareDAOControl = MockControl.createControl(IWareDAO.class);
        wareDAOMock = (IWareDAO) wareDAOControl.getMock();
        ware = new Ware("iPod", 20.0);
        bestellung = new BestellungBusinessProcess();
        bestellung.setBestellungDAO(bestellungDAOMock);
        bestellung.setKundeDAO(kundeDAOMock);
        bestellung.setWareDAO(wareDAOMock);
    }

    private void initWareMock() {
        wareDAOMock.getByID(ware.getId());
        wareDAOControl.setReturnValue(ware);
        wareDAOControl.replay();
    }

    private void initKundeMock() {
        kundeDAOMock.getByID(42);
        kundeDAOControl.setReturnValue(kunde);
        kundeDAOControl.replay();
    }



    public void testKeinKunde() {
        initWareMock();
        kundeDAOMock.getByID(-1);
        kundeDAOControl.setReturnValue(null);
        kundeDAOControl.replay();
        Einkaufswagen einkaufswagen = new Einkaufswagen(-1);
        einkaufswagen.add(ware.getId(), 1);
        try {
            bestellung.bestellen(einkaufswagen);
            fail("Exception erwartet");
        } catch (BestellungException e) {
        }
        kundeDAOControl.verify();
    }

    public void testLeererEinkaufswagen() {
        initKundeMock();
        Einkaufswagen einkaufswagen = new Einkaufswagen(kunde.getId());
        try {
            bestellung.bestellen(einkaufswagen);
            fail("Exception erwartet");
        } catch (BestellungException e) {
        }
    }

    public void testZuTeureBestellung() {
        initKundeMock();
        initWareMock();
        Einkaufswagen einkaufswagen = new Einkaufswagen(kunde.getId());
        einkaufswagen.add(ware.getId(), 3);
        try {
            bestellung.bestellen(einkaufswagen);
            fail("Exception erwartet");
        } catch (BestellungException e) {
        }
        kundeDAOControl.verify();
        wareDAOControl.verify();
    }

    public void testKeineWareBestellung() {
        initKundeMock();
        wareDAOMock.getByID(-1);
        wareDAOControl.setReturnValue(null);
        wareDAOControl.replay();
        Einkaufswagen einkaufswagen = new Einkaufswagen(kunde.getId());
        einkaufswagen.add(-1, 1);
        try {
            bestellung.bestellen(einkaufswagen);
            fail("Exception erwartet");
        } catch (BestellungException e) {
        }
        kundeDAOControl.verify();
        wareDAOControl.verify();
    }

    public void testErfolgreicheBestellung() throws Exception {
        kundeDAOMock.getByID(42);
        kundeDAOControl.setReturnValue(kunde);
        Kunde kundeNeu = new Kunde("Eberhard", "Wolff", 22.0);
        kundeNeu.setId(42);
        kundeDAOMock.update(kundeNeu);
        kundeDAOControl.replay();
        initWareMock();
        bestellungDAOMock.save(new Bestellung());
        bestellungDAOControl.setMatcher(new AlwaysMatcher());
        bestellungDAOControl.setReturnValue(new Bestellung());
        bestellungDAOControl.replay();
        Einkaufswagen einkaufswagen = new Einkaufswagen(kunde.getId());
        einkaufswagen.add(ware.getId(), 1);
        bestellung.bestellen(einkaufswagen);
        kundeDAOControl.verify();
        wareDAOControl.verify();
        bestellungDAOControl.verify();
    }

}
