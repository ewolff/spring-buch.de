package businessprocess;

public interface KreditkartenAutorisierer {
    
    boolean belasten(int nummer, double betrag);

}
