package businessprocess;

import businessobjects.Einkaufswagen;

public interface IBestellungTransaktionBusinessProcess extends
        IBestellungBusinessProcess {

    void bestellenKreditkarteTransactionManager(Einkaufswagen einkaufswagen,
            int kreditkartenNummer) throws BestellungException;

    void bestellenKreditkarteTransactionTemplate(
            final Einkaufswagen einkaufswagen, final int kreditkartenNummer)
            throws BestellungException;

    /**
     * @@org.springframework.transaction.interceptor.DefaultTransactionAttribute(org.springframework.transaction.interceptor.DefaultTransactionAttribute.PROPAGATION_REQUIRED, timeout=42,
     *                                                                                                                                                                         isolationLevelName="ISOLATION_REPEATABLE_READ")
     * @@org.springframework.transaction.interceptor.RollbackRuleAttribute(java.lang.RuntimeException.class)
     * @@org.springframework.transaction.interceptor.NoRollbackRuleAttribute(businessprocess.BestellungException.class)
     */
    void bestellenKreditkarteTransactionAnnotation(
            final Einkaufswagen einkaufswagen, final int kreditkartenNummer)
            throws BestellungException;

    void setKreditkartenAuthorisierer(KreditkartenAutorisierer authorisierer);

}
