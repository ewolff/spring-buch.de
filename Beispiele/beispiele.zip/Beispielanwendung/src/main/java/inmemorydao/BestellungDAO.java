package inmemorydao;

import java.util.ArrayList;
import java.util.List;

import businessobjects.Bestellung;
import dao.IBestellungDAO;

public class BestellungDAO extends InMemoryDAO<Bestellung> implements IBestellungDAO {

    public Bestellung save(Bestellung bestellung) {
        bestellung.setId(sequence);
        sequence++;
        store.add(bestellung);
        return bestellung;
    }

    public void deleteByIDKunde(int id_kunde) {
        store.removeAll(getByIDKunde(id_kunde));
    }

    public List getByIDKunde(int id_kunde) {
        List result = new ArrayList<Bestellung>();
        for (Bestellung bestellung : store) {
            if (bestellung.getKunde().getId() == id_kunde) {
                result.add(bestellung);
            }
        }
        return result;
    }
}
