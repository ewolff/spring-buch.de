package inmemorydao;

import java.util.ArrayList;
import java.util.List;

public class InMemoryDAO<T> {

    protected int sequence = 1;

    List<T> store = new ArrayList<T>();

    public List<T> getAll() {
        List<T> result = new ArrayList<T>();
        for (T t : store) {
            result.add(t);
        }
        return result;
    }

}
