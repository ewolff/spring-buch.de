package inmemorydao;

import java.util.ArrayList;
import java.util.List;

import businessobjects.Kunde;
import dao.IKundeDAO;

public class KundeDAO extends InMemoryDAO<Kunde> implements IKundeDAO  {


    public List getByName(String name) {
        List result = new ArrayList<Kunde>();
        for (Kunde k : store) {
            if (k.getName().equals(name)) {
                result.add(k);
            }
        }
        return result;
    }

    public Kunde save(Kunde kunde) {
        kunde.setId(sequence);
        sequence++;
        store.add(kunde);
        return kunde;
    }

    public void deleteByName(String name) {
        store.removeAll(getByName(name));
    }

    public Kunde getByID(int id) {
        for (Kunde k : store) {
            if (k.getId() == id) {
                return k;
            }
        }
        return null;
    }

    public void deleteByID(int id) {
        store.remove(getByID(id));
    }

    public void update(Kunde kunde) {
        deleteByID(kunde.getId());
        store.add(kunde);
    }


}
