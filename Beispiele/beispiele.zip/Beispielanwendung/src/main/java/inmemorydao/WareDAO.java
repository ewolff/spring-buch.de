package inmemorydao;

import java.util.ArrayList;
import java.util.List;

import businessobjects.Ware;
import dao.IWareDAO;

public class WareDAO extends InMemoryDAO<Ware> implements IWareDAO {

    public List getByBezeichnung(String bezeichnung) {
        List result = new ArrayList<Ware>();

        for (Ware ware : store) {
            if (ware.getBezeichnung().equals(bezeichnung)) {
                result.add(ware);
            }
        }
        return result;

    }

    public Ware save(Ware ware) {
        ware.setId(sequence);
        sequence++;
        store.add(ware);
        return ware;
    }

    public void deleteByBezeichnung(String bezeichnung) {
        store.removeAll(getByBezeichnung(bezeichnung));
    }

    public Ware getByID(int id) {
        for (Ware ware : store) {
            if (ware.getId() == id) {
                return ware;
            }
        }
        return null;
    }

    public void deleteByID(int id) {
        Ware ware=getByID(id);
        if (ware!=null) {
            store.remove(ware);
        }
    }

    public void update(Ware ware) {
        deleteByID(ware.getId());
        store.add(ware);
    }

}
