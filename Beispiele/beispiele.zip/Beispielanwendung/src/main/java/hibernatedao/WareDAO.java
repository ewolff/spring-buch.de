package hibernatedao;

import java.util.List;

import org.springframework.orm.hibernate3.support.HibernateDaoSupport;

import businessobjects.Ware;
import dao.IWareDAO;

public class WareDAO extends HibernateDaoSupport implements IWareDAO {

    public List getByBezeichnung(String bezeichnung) {
        return getHibernateTemplate().find(
                "from businessobjects.Ware ware where ware.bezeichnung=?",
                bezeichnung);
    }

    public Ware save(Ware ware) {
        getHibernateTemplate().save(ware);
        return ware;
    }

    public void deleteByBezeichnung(String bezeichnung) {
        List elements = getHibernateTemplate().find(
                "from businessobjects.Ware ware where ware.bezeichnung=?",
                bezeichnung);
        getHibernateTemplate().deleteAll(elements);
    }

    public Ware getByID(int id) {
        return (Ware) getHibernateTemplate().get(Ware.class, new Integer(id));
    }

    public void deleteByID(int id) {
        getHibernateTemplate().delete(getByID(id));
    }

    public void update(Ware ware) {
        getHibernateTemplate().update(ware);
    }

    public List getAll() {
        return getHibernateTemplate().loadAll(Ware.class);
    }

}
