package aop;

import java.sql.Types;

import javax.sql.DataSource;

import org.aopalliance.intercept.MethodInterceptor;
import org.aopalliance.intercept.MethodInvocation;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.jdbc.object.SqlUpdate;

public class DBTraceInterceptor implements MethodInterceptor, InitializingBean {

    static class LogInsert extends SqlUpdate {

        public LogInsert(DataSource ds) {
            super(ds, "INSERT INTO DBLOG(MESSAGE) VALUES(?)",
                    new int[] { Types.VARCHAR });
            compile();
        }
    }

    private DataSource datasource;

    private LogInsert logInsert;

    public DataSource getDatasource() {
        return datasource;
    }

    public void setDatasource(DataSource datasource) {
        this.datasource = datasource;
    }

    public Object invoke(MethodInvocation invocation) throws Throwable {

        try {
            Object rval = invocation.proceed();
            logInsert.update("Erfolgreiche Bestellung "
                    + invocation.getArguments()[0].toString());
            return rval;

        } catch (Throwable ex) {
            logInsert.update("Fehler bei Bestellung "
                    + invocation.getArguments()[0].toString() + "\n"
                    + ex.toString());
            throw ex;

        }
    }

    public void afterPropertiesSet() throws Exception {
        logInsert = new LogInsert(datasource);
    }

}
