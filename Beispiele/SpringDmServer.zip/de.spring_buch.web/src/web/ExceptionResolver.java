package web;

import java.io.PrintWriter;
import java.io.StringWriter;
import java.io.Writer;
import java.util.HashMap;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.web.servlet.HandlerExceptionResolver;
import org.springframework.web.servlet.ModelAndView;

public class ExceptionResolver implements HandlerExceptionResolver {

    public ModelAndView resolveException(HttpServletRequest request,
            HttpServletResponse response, Object handler, Exception ex) {
        Map<String, String> model = new HashMap<String, String>();
        Writer writer = new StringWriter();
        ex.printStackTrace( new PrintWriter( writer ) );
        model.put("stacktrace", writer.toString());
        model.put("message", ex.getLocalizedMessage());
        model.put("handler", handler.toString());
        return new ModelAndView("exception",model);
    }

}
