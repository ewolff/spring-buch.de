package businessobjects;

public class Einkaufswagen {

}
