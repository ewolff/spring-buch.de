package introductions;

public class Bean {
    
    public void doIt() {
        
    }

}
