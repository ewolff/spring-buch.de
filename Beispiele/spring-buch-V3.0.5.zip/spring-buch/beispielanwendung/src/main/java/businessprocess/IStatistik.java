package businessprocess;

public interface IStatistik {

    void ausgeben();

}