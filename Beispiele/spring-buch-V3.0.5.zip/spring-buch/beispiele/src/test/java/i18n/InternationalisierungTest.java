package i18n;

import java.util.Locale;

import junit.framework.Assert;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

@ContextConfiguration("/i18n.xml")
@RunWith(SpringJUnit4ClassRunner.class)
public class InternationalisierungTest {

	@Autowired
	private MessageSource messageSource;
	
	@Test
	public void testEnglish() {
		// liest aus messages_EN.properties unter dem entsprechenden Schl�ssel
		Assert.assertEquals("Welcome!", 
				messageSource.getMessage("welcome", null, Locale.ENGLISH));
		// mit Ersetzung von Parametern
		Assert.assertEquals("Welcome to Spring !", 
				messageSource.getMessage("welcome.param",new Object[] {"Spring"}, Locale.ENGLISH));
	}
	
	@Test
	public void testGerman() {
		// liest aus messages_DE.properties unter dem entsprechenden Schl�ssel
		Assert.assertEquals("Willkommen!", 
				messageSource.getMessage("welcome", null, Locale.GERMAN));
		// mit Ersetzung von Parametern
		Assert.assertEquals("Willkommen zu Spring !", 
				messageSource.getMessage("welcome.param",new Object[] {"Spring"}, Locale.GERMAN));
	}
	
}
