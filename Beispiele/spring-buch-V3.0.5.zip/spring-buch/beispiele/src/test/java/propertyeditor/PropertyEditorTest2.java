package propertyeditor;

import org.springframework.test.context.ContextConfiguration;

@ContextConfiguration(value="/propertyeditor-2.xml", inheritLocations=false)
public class PropertyEditorTest2 extends PropertyEditorTest {


}
