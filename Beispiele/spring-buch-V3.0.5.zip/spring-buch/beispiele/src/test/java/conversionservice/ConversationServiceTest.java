package conversionservice;

import org.springframework.test.context.ContextConfiguration;

import propertyeditor.PropertyEditorTest;

@ContextConfiguration(value = "/conversionservice.xml", inheritLocations = false)
public class ConversationServiceTest extends PropertyEditorTest {

}
