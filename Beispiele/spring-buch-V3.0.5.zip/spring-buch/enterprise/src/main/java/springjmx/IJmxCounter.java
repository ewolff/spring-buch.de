package springjmx;

public interface IJmxCounter {

    int getCount();

    void inc();

}