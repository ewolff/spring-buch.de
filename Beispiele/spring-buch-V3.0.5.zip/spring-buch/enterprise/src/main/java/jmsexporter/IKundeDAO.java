package jmsexporter;

public interface IKundeDAO {
    
    Kunde getById(int id);

}
