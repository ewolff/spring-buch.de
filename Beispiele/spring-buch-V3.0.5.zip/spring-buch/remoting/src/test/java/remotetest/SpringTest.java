package remotetest;

import org.springframework.test.context.ContextConfiguration;

@ContextConfiguration("/spring-client.xml")
public class SpringTest extends RemoteBase {

}
