package remotetest;

import org.springframework.test.context.ContextConfiguration;

@ContextConfiguration("/burlap-client.xml")
public class BurlapTest extends RemoteBase {

}
