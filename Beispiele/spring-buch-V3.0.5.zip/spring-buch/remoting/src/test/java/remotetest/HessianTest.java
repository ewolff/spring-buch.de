package remotetest;

import org.springframework.test.context.ContextConfiguration;

@ContextConfiguration("/hessian-client.xml")
public class HessianTest extends RemoteBase {

}
