package springperformance;

public interface IDoIt {

    void doIt();

    String getName();

    void setName(String name);

}