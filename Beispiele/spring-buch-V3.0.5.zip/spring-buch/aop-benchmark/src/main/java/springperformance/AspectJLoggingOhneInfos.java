package springperformance;

public class AspectJLoggingOhneInfos implements IDoIt {

    private String name;
    
    public void doIt() {
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
    
    

}
