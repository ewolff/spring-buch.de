package eltestxml;

public class EineBean {

	public String name="wolff";

	public String getName() {
		return name;
	}

	
	
}
