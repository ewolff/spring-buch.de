package eltestxml;

public class EineAndereBean {

	private String name;
	private String country;
	private String nochEinName;
	private int zwei;

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public void setCountry(String country) {
		this.country = country;
	}

	public String getCountry() {
		return country;
	}

	public void setNochEinNname(String nochEinName) {
		this.nochEinName = nochEinName;
	}

	public String getNochEinName() {
		return nochEinName;
	}

	public void setZwei(int zwei) {
		this.zwei = zwei;
	}

	public int getZwei() {
		return zwei;
	}

}
